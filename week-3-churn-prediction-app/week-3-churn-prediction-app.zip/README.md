
# Customer Churn Prediction App

A Machine Learning application that predicts whether a telecom customer is likely to leave the service.

## Features
- Customer information input
- Real-time churn prediction
- Churn probability score
- Customer retention recommendations

## Technologies Used
- Python
- Pandas
- Scikit-learn
- Streamlit
- Joblib

## Model
Random Forest Classifier

## Evaluation Metrics
- Accuracy
- Precision
- Recall
- F1-Score
- ROC-AUC Score

## How to Run

1. Install the required libraries:
   pip install -r requirements.txt

2. Run the Streamlit application:
   streamlit run app.py

## Project Files
- app.py
- churn_model.pkl
- requirements.txt
- README.md
